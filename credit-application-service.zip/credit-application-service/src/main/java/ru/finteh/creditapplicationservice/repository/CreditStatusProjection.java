package ru.finteh.creditapplicationservice.repository;

public interface CreditStatusProjection {
    String getStatus();
}
