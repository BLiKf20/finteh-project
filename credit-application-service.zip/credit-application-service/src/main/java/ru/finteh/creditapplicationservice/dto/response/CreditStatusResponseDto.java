package ru.finteh.creditapplicationservice.dto.response;

public record CreditStatusResponseDto(
    String status
) {

}
