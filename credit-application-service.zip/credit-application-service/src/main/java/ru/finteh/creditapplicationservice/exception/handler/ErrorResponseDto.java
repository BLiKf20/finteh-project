package ru.finteh.creditapplicationservice.exception.handler;

public record ErrorResponseDto(String errorMessage) {
}

